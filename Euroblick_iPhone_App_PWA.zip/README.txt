EUROBLICK MOBILE – iPhone App (PWA)

1. ZIP entpacken.
2. Alle Dateien (index.html, manifest.webmanifest, sw.js und die drei Icons) in das GitHub-Repository euroblick-mobile hochladen, ins Stammverzeichnis.
3. GitHub Settings > Pages > Deploy from a branch > main > /(root).
4. Auf dem iPhone die veröffentlichte HTTPS-Adresse in Safari öffnen.
5. Safari: Teilen > Zum Home-Bildschirm > Hinzufügen.
6. Euroblick über das Home-Bildschirm-Symbol öffnen.

WICHTIG: Daten werden nur lokal im jeweiligen Browser/App-Speicher gespeichert, nicht zwischen Geräten synchronisiert. Regelmäßig JSON exportieren. Dateien und Buchungen niemals ins öffentliche GitHub-Repository hochladen.
